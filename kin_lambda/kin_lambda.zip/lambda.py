import base64
import json
import aws_kinesis_agg
import boto3
import datetime


def lambda_handler(event, context):
    """
    Receive a batch of events from Kinesis and insert into our DynamoDB table
    """
    print('Received request')
    item = None
    dynamo_db = boto3.resource('dynamodb')
    table = dynamo_db.Table('benchmark_kinesis')
    decoded_record_data = [record['kinesis']['data'] for record in event['Records']]
    records = deaggregate_records(decoded_record_data)
    deserialized_data = [decoded_record for decoded_record in records]

    with table.batch_writer() as batch_writer:
        for data in deserialized_data:
            item = {
                'dbhash': data
            }
            # Add a processed time so we have a rough idea how far behind we are
            #item['processed'] = datetime.datetime.utcnow().isoformat()
            batch_writer.put_item(Item=item)

    # Print the last item to make it easy to see how we're doing
    #print(json.dumps(item))
    print('Number of records: {}'.format(str(len(deserialized_data))))
